/* e-mail复制功能*/ 
function mycopy(){		
          var copyval=document.getElementById("copyval");
          copyval.select();		  
          document.execCommand('copy');		 
          alert("Geek的邮箱已经复制到剪切板了!");
}
/*导航栏二维码*/
function showImg(){ 
document.getElementById("wxImg").style.display='block'; 
} 
function hideImg(){ 
document.getElementById("wxImg").style.display='none'; 
} 
     